#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GESTIONNAIRE PRÊTS IMMOBILIERS - Ingestion et Lookup Échéances
================================================================

Fonctions :
1. Ingestion : Stocker tableaux d'amortissement en BD (données de référence)
2. Lookup : Retrouver ventilation intérêts/capital pour une échéance donnée

Usage :
- Email tableau amortissement → ingest_tableau_pret()
- Email relevé bancaire → lookup_echeance()

Tables utilisées :
- prets_immobiliers : Contrats
- echeances_prets : Échéancier ligne par ligne
"""

from datetime import datetime, date
from dateutil.relativedelta import relativedelta
from typing import Dict, List, Optional, Tuple
from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from models_module2 import PretImmobilier, EcheancePret


class PretsManager:
    """Gestionnaire des prêts immobiliers"""

    def __init__(self, session: Session):
        self.session = session

    def ingest_tableau_pret(self,
                           pret_data: Dict,
                           echeances_data: List[Dict],
                           source_email_id: str = None,
                           source_document: str = None) -> Tuple[bool, str, Optional[int]]:
        """
        Ingère un tableau d'amortissement complet en BD

        Args:
            pret_data: Données contrat (dict from ParseurTableauPret)
            echeances_data: Lignes échéancier (list of dicts)
            source_email_id: ID email source
            source_document: Nom fichier PDF source

        Returns:
            (success, message, pret_id)
        """
        try:
            # Vérifier si prêt existe déjà
            numero_pret = pret_data.get('numero_pret')
            if not numero_pret:
                return False, "Numéro de prêt manquant", None

            pret_existant = self.session.query(PretImmobilier).filter_by(
                numero_pret=numero_pret
            ).first()

            print(f"[PRETS_MGR] Recherche prêt existant '{numero_pret}': {'TROUVÉ' if pret_existant else 'NON TROUVÉ'}", flush=True)

            if pret_existant:
                print(f"[PRETS_MGR] Prêt existant ID={pret_existant.id}, suppression en cours...", flush=True)
                # Prêt existe déjà - vérifier si échéances sont complètes
                nb_echeances_existantes = self.session.query(EcheancePret).filter_by(
                    pret_id=pret_existant.id
                ).count()

                nb_echeances_attendues = len(echeances_data) if echeances_data else 0

                # Valider que les valeurs ne sont pas None
                if nb_echeances_existantes is None:
                    nb_echeances_existantes = 0
                if nb_echeances_attendues is None:
                    nb_echeances_attendues = 0

                if nb_echeances_existantes >= nb_echeances_attendues and nb_echeances_attendues > 0:
                    return True, f"Prêt {numero_pret} déjà complet en BD ({nb_echeances_existantes} échéances)", pret_existant.id
                else:
                    # Ingestion partielle précédente → supprimer et réinsérer
                    print(f"[PRETS_MGR] Ingestion partielle ({nb_echeances_existantes}/{nb_echeances_attendues}), suppression et réinsertion...", flush=True)
                    # Utiliser synchronize_session=False pour éviter erreurs
                    nb_echeances_supprimees = self.session.query(EcheancePret).filter_by(pret_id=pret_existant.id).delete(synchronize_session=False)
                    nb_prets_supprimes = self.session.query(PretImmobilier).filter_by(id=pret_existant.id).delete(synchronize_session=False)
                    self.session.flush()
                    print(f"[PRETS_MGR] Supprimés: {nb_echeances_supprimees} échéances, {nb_prets_supprimes} prêt(s)", flush=True)
                    # Continuer avec nouvelle insertion ci-dessous

            # Créer PretImmobilier
            # Parser les dates
            date_debut = self._parse_date(pret_data.get('date_debut'))
            date_fin = self._parse_date(pret_data.get('date_fin'))
            duree_mois = pret_data.get('duree_mois', 0)

            # Calculer date_fin si manquante (date_debut + duree_mois)
            if date_debut and not date_fin and duree_mois > 0:
                date_fin = date_debut + relativedelta(months=duree_mois)
                print(f"[PRETS_MGR] date_fin calculée automatiquement: {date_fin}", flush=True)

            pret = PretImmobilier(
                numero_pret=numero_pret,
                banque=pret_data.get('banque', 'INCONNU'),
                libelle=pret_data.get('libelle', f"Prêt {numero_pret}"),
                montant_initial=Decimal(str(pret_data.get('montant_initial', 0))),
                taux_annuel=Decimal(str(pret_data.get('taux_annuel', 0))),
                duree_mois=duree_mois,
                date_debut=date_debut,
                date_fin=date_fin,
                type_amortissement=pret_data.get('type_amortissement', 'AMORTISSEMENT_CONSTANT'),
                mois_franchise=pret_data.get('mois_franchise', 0),
                echeance_mensuelle=Decimal(str(pret_data.get('echeance_mensuelle', 0))) if pret_data.get('echeance_mensuelle') else None,
                interet_mensuel_franchise=Decimal(str(pret_data.get('interet_mensuel_franchise', 0))) if pret_data.get('interet_mensuel_franchise') else None,
                assurance_emprunteur=pret_data.get('assurance_emprunteur', False),
                assures=pret_data.get('assures'),
                source_email_id=source_email_id,
                source_document=source_document,
                actif=True
            )

            print(f"[PRETS_MGR] Création prêt {numero_pret}", flush=True)
            self.session.add(pret)
            self.session.flush()  # Pour obtenir pret.id
            print(f"[PRETS_MGR] Prêt créé avec ID={pret.id}", flush=True)

            # CRITIQUE: Nettoyer les échéances orphelines qui pourraient exister avec ce pret_id
            # (cas où un prêt précédent a été rollback mais ses échéances sont restées)
            nb_orphelines = self.session.query(EcheancePret).filter_by(pret_id=pret.id).count()
            if nb_orphelines > 0:
                print(f"[PRETS_MGR] ALERTE: {nb_orphelines} échéances orphelines détectées pour pret_id={pret.id}, suppression...", flush=True)
                self.session.query(EcheancePret).filter_by(pret_id=pret.id).delete(synchronize_session=False)
                self.session.flush()
                print(f"[PRETS_MGR] Échéances orphelines supprimées", flush=True)

            # Vérifier doublons dans echeances_data (ne devrait JAMAIS arriver)
            dates_vues = set()
            doublons = []

            for ech_data in echeances_data:
                date_str = ech_data.get('date_echeance')
                if date_str in dates_vues:
                    doublons.append(date_str)
                dates_vues.add(date_str)

            if doublons:
                erreur_msg = f"ERREUR PARSING: {len(doublons)} dates en doublon détectées: {doublons[:10]}. Le parsing a échoué à extraire correctement les échéances numérotées."
                print(f"[PRETS_MGR] {erreur_msg}", flush=True)
                self.session.rollback()
                return False, erreur_msg, None

            # Créer EcheancePret pour chaque ligne
            nb_echeances = 0
            for idx, ech_data in enumerate(echeances_data, start=1):
                # Générer numero_echeance automatiquement si manquant
                numero_ech = ech_data.get('numero_echeance')
                if numero_ech is None:
                    numero_ech = idx  # Numéro séquentiel (1, 2, 3...)

                echeance = EcheancePret(
                    pret_id=pret.id,
                    numero_echeance=numero_ech,
                    date_echeance=self._parse_date(ech_data.get('date_echeance')),
                    montant_echeance=Decimal(str(ech_data.get('montant_echeance', 0))),
                    montant_interet=Decimal(str(ech_data.get('montant_interet', 0))),
                    montant_capital=Decimal(str(ech_data.get('montant_capital', 0))),
                    capital_restant_du=Decimal(str(ech_data.get('capital_restant_du', 0))),
                    montant_assurance=Decimal(str(ech_data.get('montant_assurance', 0))) if ech_data.get('montant_assurance') else Decimal('0'),
                    comptabilise=False
                )
                self.session.add(echeance)
                nb_echeances += 1

            print(f"[PRETS_MGR] {nb_echeances} échéances créées, commit en cours...", flush=True)
            self.session.commit()
            print(f"[PRETS_MGR] COMMIT RÉUSSI pour prêt {numero_pret}", flush=True)

            # NOTE: Les échéances sont déjà complétées par module2_workflow_v2.py::_generer_echeances()
            # Pas besoin de générer ici avec _generer_echeances_manquantes()

            message = f"Prêt {numero_pret} ingéré : {nb_echeances} échéances stockées"
            return True, message, pret.id

        except IntegrityError as e:
            print(f"[PRETS_MGR] ERREUR IntegrityError: {str(e)[:200]}", flush=True)
            self.session.rollback()
            return False, f"Erreur intégrité BD: {str(e)[:200]}", None

        except Exception as e:
            print(f"[PRETS_MGR] ERREUR Exception: {str(e)[:200]}", flush=True)
            self.session.rollback()
            return False, f"Erreur ingestion: {str(e)[:200]}", None

    def lookup_echeance(self,
                       numero_pret: str,
                       date_echeance: date,
                       tolerance_jours: int = 3) -> Optional[Dict]:
        """
        Recherche ventilation intérêts/capital pour une échéance donnée

        Args:
            numero_pret: Numéro du prêt (ex: "5009736BRM0911AH")
            date_echeance: Date de l'échéance (date object)
            tolerance_jours: Tolérance en jours pour trouver l'échéance

        Returns:
            {
              "echeance_id": 123,
              "pret_id": 1,
              "numero_pret": "5009736BRM0911AH",
              "numero_echeance": 5,
              "date_echeance": date(2023, 9, 15),
              "montant_echeance": 1166.59,
              "montant_interet": 215.32,
              "montant_capital": 951.27,
              "capital_restant_du": 245234.89,
              "montant_assurance": 0,
              "comptabilise": False
            }
            ou None si non trouvée
        """
        # Trouver le prêt
        pret = self.session.query(PretImmobilier).filter_by(
            numero_pret=numero_pret,
            actif=True
        ).first()

        if not pret:
            return None

        # Chercher échéance avec tolérance de date
        from sqlalchemy import and_, func

        # Chercher date exacte d'abord
        echeance = self.session.query(EcheancePret).filter(
            and_(
                EcheancePret.pret_id == pret.id,
                EcheancePret.date_echeance == date_echeance
            )
        ).first()

        # Si pas trouvée, chercher avec tolérance
        if not echeance and tolerance_jours > 0:
            from datetime import timedelta
            date_min = date_echeance - timedelta(days=tolerance_jours)
            date_max = date_echeance + timedelta(days=tolerance_jours)

            echeance = self.session.query(EcheancePret).filter(
                and_(
                    EcheancePret.pret_id == pret.id,
                    EcheancePret.date_echeance >= date_min,
                    EcheancePret.date_echeance <= date_max
                )
            ).order_by(
                # Trier par proximité de date
                func.abs(func.extract('epoch', EcheancePret.date_echeance - date_echeance))
            ).first()

        if not echeance:
            return None

        # Retourner données formatées
        return {
            "echeance_id": echeance.id,
            "pret_id": pret.id,
            "numero_pret": pret.numero_pret,
            "numero_echeance": echeance.numero_echeance,
            "date_echeance": echeance.date_echeance,
            "montant_echeance": float(echeance.montant_echeance),
            "montant_interet": float(echeance.montant_interet),
            "montant_capital": float(echeance.montant_capital),
            "capital_restant_du": float(echeance.capital_restant_du),
            "montant_assurance": float(echeance.montant_assurance) if echeance.montant_assurance else 0,
            "comptabilise": echeance.comptabilise
        }

    def marquer_echeance_comptabilisee(self,
                                      echeance_id: int,
                                      ecriture_comptable_id: int) -> bool:
        """
        Marque une échéance comme comptabilisée

        Args:
            echeance_id: ID de l'échéance
            ecriture_comptable_id: ID de l'écriture comptable créée

        Returns:
            success (bool)
        """
        try:
            echeance = self.session.query(EcheancePret).get(echeance_id)
            if not echeance:
                return False

            echeance.comptabilise = True
            echeance.ecriture_comptable_id = ecriture_comptable_id
            echeance.date_comptabilisation = datetime.utcnow()

            self.session.commit()
            return True

        except Exception:
            self.session.rollback()
            return False

    def get_pret_by_numero(self, numero_pret: str) -> Optional[Dict]:
        """
        Récupère les infos d'un prêt par son numéro

        Returns:
            dict ou None
        """
        pret = self.session.query(PretImmobilier).filter_by(
            numero_pret=numero_pret,
            actif=True
        ).first()

        if not pret:
            return None

        return {
            "id": pret.id,
            "numero_pret": pret.numero_pret,
            "banque": pret.banque,
            "montant_initial": float(pret.montant_initial),
            "taux_annuel": float(pret.taux_annuel),
            "duree_mois": pret.duree_mois,
            "date_debut": pret.date_debut,
            "date_fin": pret.date_fin,
            "type_amortissement": pret.type_amortissement,
            "echeance_mensuelle": float(pret.echeance_mensuelle) if pret.echeance_mensuelle else None,
            "actif": pret.actif
        }

    def list_prets_actifs(self) -> List[Dict]:
        """Liste tous les prêts actifs"""
        prets = self.session.query(PretImmobilier).filter_by(actif=True).all()

        return [{
            "id": p.id,
            "numero_pret": p.numero_pret,
            "banque": p.banque,
            "montant_initial": float(p.montant_initial),
            "echeance_mensuelle": float(p.echeance_mensuelle) if p.echeance_mensuelle else None
        } for p in prets]

    def _generer_echeances_manquantes(self, pret: PretImmobilier) -> int:
        """
        Génère automatiquement les échéances manquantes à partir du 15/05/2024

        Args:
            pret: Objet PretImmobilier avec échéances déjà insérées

        Returns:
            Nombre d'échéances générées
        """
        from dateutil.relativedelta import relativedelta

        # Récupérer toutes les échéances existantes, triées par date
        echeances_existantes = self.session.query(EcheancePret).filter_by(
            pret_id=pret.id
        ).order_by(EcheancePret.date_echeance).all()

        if not echeances_existantes:
            print(f"[PRETS_MGR] Aucune échéance existante pour générer la suite", flush=True)
            return 0

        # Dernière échéance extraite
        derniere_echeance = echeances_existantes[-1]
        date_ref = date(2024, 5, 15)  # Date de référence : 15/05/2024

        # Si la dernière échéance est avant le 15/05/2024, on ne génère rien
        if derniere_echeance.date_echeance < date_ref:
            print(f"[PRETS_MGR] Dernière échéance ({derniere_echeance.date_echeance}) avant 15/05/2024, pas de génération", flush=True)
            return 0

        # Si on a déjà toutes les échéances (jusqu'à date_fin), on ne génère rien
        if pret.date_fin and derniere_echeance.date_echeance >= pret.date_fin:
            print(f"[PRETS_MGR] Échéances déjà complètes jusqu'à {pret.date_fin}", flush=True)
            return 0

        # Paramètres pour génération
        taux_mensuel = pret.taux_annuel / Decimal('12') / Decimal('100')  # Taux annuel → mensuel décimal
        capital_restant = derniere_echeance.capital_restant_du
        date_courante = derniere_echeance.date_echeance
        numero_echeance = derniere_echeance.numero_echeance
        mensualite = pret.echeance_mensuelle if pret.echeance_mensuelle else derniere_echeance.montant_echeance

        print(f"[PRETS_MGR] Génération auto depuis {date_courante} (capital restant: {capital_restant}€)", flush=True)
        print(f"[PRETS_MGR] Taux mensuel: {taux_mensuel}, Mensualité: {mensualite}€", flush=True)

        nb_generees = 0
        max_echeances = 500  # Limite de sécurité

        while capital_restant > Decimal('0.01') and nb_generees < max_echeances:
            # Date suivante (+1 mois)
            date_courante = date_courante + relativedelta(months=1)

            # Vérifier si on dépasse date_fin
            if pret.date_fin and date_courante > pret.date_fin:
                break

            # Calculer intérêts
            montant_interet = capital_restant * taux_mensuel

            # Calculer capital amorti
            montant_capital = mensualite - montant_interet

            # Si capital > capital_restant, c'est la dernière échéance
            if montant_capital >= capital_restant:
                montant_capital = capital_restant
                montant_echeance = montant_interet + montant_capital
                capital_restant = Decimal('0')
            else:
                montant_echeance = mensualite
                capital_restant -= montant_capital

            # Créer échéance
            numero_echeance += 1
            nouvelle_echeance = EcheancePret(
                pret_id=pret.id,
                numero_echeance=numero_echeance,
                date_echeance=date_courante,
                montant_echeance=montant_echeance,
                montant_interet=montant_interet,
                montant_capital=montant_capital,
                capital_restant_du=capital_restant,
                montant_assurance=Decimal('0'),
                comptabilise=False
            )
            self.session.add(nouvelle_echeance)
            nb_generees += 1

            # Commit tous les 50 pour éviter surcharge mémoire
            if nb_generees % 50 == 0:
                self.session.commit()
                print(f"[PRETS_MGR] {nb_generees} échéances générées (commit intermédiaire)", flush=True)

        # Commit final
        if nb_generees > 0:
            self.session.commit()
            print(f"[PRETS_MGR] {nb_generees} échéances générées au total", flush=True)

        return nb_generees

    def inserer_pret_et_echeances(self,
                                   pret_data: Dict,
                                   echeances_data: List[Dict]) -> Tuple[bool, str, Optional[int]]:
        """
        Insère un prêt et ses échéances en BD

        Wrapper de ingest_tableau_pret() pour compatibilité avec tools V6

        Args:
            pret_data: Données du prêt
            echeances_data: Liste des échéances

        Returns:
            (success, message, pret_id)
        """
        return self.ingest_tableau_pret(
            pret_data=pret_data,
            echeances_data=echeances_data,
            source_email_id=None,
            source_document=pret_data.get('fichier_reference')
        )

    def get_echeance(self, numero_pret: str, date_echeance: str) -> Optional[EcheancePret]:
        """
        Récupère l'objet EcheancePret pour un prêt et une date donnés

        Version simplifiée de lookup_echeance() qui retourne l'objet ORM directement
        Utilisée par les tools de Function Calling

        Args:
            numero_pret: Numéro du prêt (ex: '5009736BRM0911AH')
            date_echeance: Date au format YYYY-MM-DD ou objet date

        Returns:
            EcheancePret ou None si non trouvée
        """
        # Parser la date si c'est une string
        if isinstance(date_echeance, str):
            date_echeance = self._parse_date(date_echeance)

        if not date_echeance:
            return None

        # Trouver le prêt
        pret = self.session.query(PretImmobilier).filter_by(
            numero_pret=numero_pret,
            actif=True
        ).first()

        if not pret:
            return None

        # Chercher l'échéance
        from sqlalchemy import and_

        echeance = self.session.query(EcheancePret).filter(
            and_(
                EcheancePret.pret_id == pret.id,
                EcheancePret.date_echeance == date_echeance
            )
        ).first()

        return echeance

    @staticmethod
    def _parse_date(date_str: any) -> Optional[date]:
        """Parse string ou date object vers date"""
        if not date_str:
            return None

        if isinstance(date_str, date):
            return date_str

        if isinstance(date_str, datetime):
            return date_str.date()

        # Parse string (format: YYYY-MM-DD)
        try:
            return datetime.strptime(str(date_str), '%Y-%m-%d').date()
        except ValueError:
            # Essayer DD/MM/YYYY
            try:
                return datetime.strptime(str(date_str), '%d/%m/%Y').date()
            except ValueError:
                return None


if __name__ == "__main__":
    print("OK: PretsManager prêt à l'emploi")
