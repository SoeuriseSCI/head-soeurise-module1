#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WORKFLOW ÉVÉNEMENTS COMPTABLES
==============================
Orchestration complète du traitement des événements comptables.

Date: 05/11/2025
Auteur: Module Phase 1 - Accounting Events

WORKFLOW COMPLET:
-----------------
1. EXTRACTION: PDF → Événements bruts
2. CRÉATION: Événements → Base de données (avec détection de doublons)
3. DÉTECTION: Classification automatique du type d'événement
4. PROPOSITION: Génération des écritures comptables suggérées
5. VALIDATION: (manuel - externe à ce module)
6. COMPTABILISATION: Création des écritures définitives

Ce module gère les étapes 1-4 automatiquement.
"""

import os
from datetime import datetime
from typing import Dict, List, Optional
from sqlalchemy.orm import Session

from extracteur_intelligent import ExtracteurIntelligent
from gestionnaire_evenements import GestionnaireEvenements, afficher_statistiques
from detecteurs_evenements import FactoryDetecteurs
from models_module2 import get_session


class WorkflowEvenements:
    """
    Orchestrateur du workflow complet de traitement des événements
    """

    def __init__(self, database_url: str, phase: int = 1):
        """
        Initialise le workflow

        Args:
            database_url: URL de connexion PostgreSQL
            phase: Phase de traitement (1, 2, 3)
        """
        self.database_url = database_url
        self.phase = phase
        self.session = get_session(database_url)
        self.gestionnaire = GestionnaireEvenements(self.session, phase=phase)

    def __del__(self):
        """Ferme la session à la destruction"""
        if hasattr(self, 'session'):
            self.session.close()

    def traiter_pdf(
        self,
        pdf_path: str,
        email_metadata: Optional[Dict] = None,
        auto_detect: bool = True
    ) -> Dict:
        """
        Traite un PDF complet: analyse → validation → extraction → création → détection

        Args:
            pdf_path: Chemin vers le PDF
            email_metadata: Métadonnées de l'email source
            auto_detect: Si True, lance la détection automatique des types

        Returns:
            Dictionnaire avec résultats:
                - total_operations: Nombre d'opérations extraites
                - evenements_crees: Nombre d'événements créés
                - doublons_detectes: Nombre de doublons ignorés
                - erreurs: Nombre d'erreurs
                - types_detectes: Nombre de types détectés
                - ids_crees: Liste des IDs créés
                - periode_document: Période détectée
                - exercice_valide: Boolean
        """
        print()
        print("=" * 80)
        print(f"WORKFLOW ÉVÉNEMENTS - PDF: {os.path.basename(pdf_path)}")
        print("=" * 80)
        print()

        # ÉTAPE 0: RÉCUPÉRATION DE L'EXERCICE COMPTABLE
        print("🔍 ÉTAPE 0/2: RÉCUPÉRATION DE L'EXERCICE COMPTABLE")
        print("-" * 80)

        # Récupérer l'exercice comptable en cours
        from sqlalchemy import text
        result = self.session.execute(text("""
            SELECT date_debut, date_fin, statut
            FROM exercices_comptables
            WHERE statut = 'OUVERT'
            ORDER BY date_debut DESC
            LIMIT 1
        """))
        exercice = result.fetchone()

        if not exercice:
            print("⚠️  Aucun exercice comptable ouvert")
            return {'total_operations': 0, 'evenements_crees': 0, 'doublons_detectes': 0,
                    'erreurs': 1, 'types_detectes': 0, 'ids_crees': [],
                    'periode_document': 'Indéterminée',
                    'exercice_valide': False, 'message_erreur': 'Aucun exercice ouvert'}

        exercice_debut = str(exercice[0])
        exercice_fin = str(exercice[1])

        print(f"   Exercice: {exercice_debut} → {exercice_fin}")
        print()

        # ÉTAPE 1: ANALYSE INTELLIGENTE DU PDF PAR CLAUDE
        print("🧠 ÉTAPE 1/2: ANALYSE INTELLIGENTE DU PDF (CLAUDE)")
        print("-" * 80)
        print("   Claude va analyser le PDF complet et identifier les événements")
        print("   économiques uniques en rapprochant automatiquement les documents.")
        print()

        extracteur = ExtracteurIntelligent()

        try:
            evenements, metadata = extracteur.analyser_pdf(
                pdf_path=pdf_path,
                exercice_debut=exercice_debut,
                exercice_fin=exercice_fin
            )

            print(f"✅ {len(evenements)} événements économiques identifiés par Claude")
            print(f"   (analyse intelligente avec rapprochement automatique)")
            print()

            # Convertir le format de l'extracteur intelligent vers le format attendu par le gestionnaire
            # Format extracteur intelligent: {date, libelle, montant, type_operation, source, justificatif, categorie}
            # Format gestionnaire: {date_operation, libelle, montant, type_operation, email_metadata, ...}

            operations = []
            for evt in evenements:
                operation = {
                    'date_operation': evt['date'],
                    'libelle': evt['libelle'],
                    'montant': evt['montant'],
                    'type_operation': evt['type_operation'],
                    'source_document': evt.get('source', 'claude'),
                    'justificatif': evt.get('justificatif'),
                    'categorie_suggeree': evt.get('categorie'),
                    'email_metadata': email_metadata
                }
                operations.append(operation)

            # Variables pour compatibilité avec la suite du code
            doc_debut = None
            doc_fin = None

            # Extraire les dates min/max des événements
            if evenements:
                dates = [evt['date'] for evt in evenements if evt.get('date')]
                if dates:
                    doc_debut = min(dates)
                    doc_fin = max(dates)
                    print(f"   Période détectée: {doc_debut} → {doc_fin}")

        except Exception as e:
            print(f"❌ Erreur lors de l'analyse du PDF: {e}")
            import traceback
            traceback.print_exc()
            return {'total_operations': 0, 'evenements_crees': 0, 'doublons_detectes': 0,
                    'erreurs': 1, 'types_detectes': 0, 'ids_crees': [],
                    'periode_document': 'Erreur', 'exercice_valide': False,
                    'message_erreur': f'Erreur extraction: {e}'}

        print()

        # ÉTAPE 2: CRÉATION DES ÉVÉNEMENTS + DÉTECTION DES TYPES
        print("💾 ÉTAPE 2/2: CRÉATION DES ÉVÉNEMENTS + DÉTECTION")
        print("-" * 80)

        stats_creation = self.gestionnaire.creer_evenements_batch(operations)

        print()
        print(f"✅ Événements créés: {stats_creation['crees']}")
        print(f"⚠️  Doublons détectés: {stats_creation['doublons']}")
        print(f"❌ Erreurs: {stats_creation['erreurs']}")
        print()

        # DÉTECTION DES TYPES
        types_detectes = 0
        if auto_detect and stats_creation['crees'] > 0:
            import sys
            print("🔍 Détection des types d'événements...")
            print("-" * 80)
            sys.stdout.flush()

            for evt_id in stats_creation['ids_crees']:
                try:
                    type_evt = self.gestionnaire.detecter_type_evenement(evt_id)
                    if type_evt:
                        types_detectes += 1
                        print(f"✅ Événement #{evt_id}: {type_evt}")
                        sys.stdout.flush()
                        # Marquer la phase de traitement
                        self.gestionnaire.marquer_phase_traitement(evt_id, self.phase)
                except Exception as e:
                    print(f"⚠️  Erreur détection événement #{evt_id}: {e}")
                    sys.stdout.flush()
                    continue

            print()
            print(f"✅ Types détectés: {types_detectes}/{stats_creation['crees']}")
            print()
            sys.stdout.flush()

        # RÉSUMÉ
        print("=" * 80)
        print("RÉSUMÉ")
        print("=" * 80)
        print()
        print(f"📊 Opérations extraites: {len(operations)}")
        print(f"✅ Événements créés: {stats_creation['crees']}")
        print(f"🔍 Types détectés: {types_detectes}")
        print(f"⚠️  Doublons ignorés: {stats_creation['doublons']}")
        print(f"❌ Erreurs: {stats_creation['erreurs']}")
        print()

        return {
            'total_operations': len(operations),
            'evenements_crees': stats_creation['crees'],
            'doublons_detectes': stats_creation['doublons'],
            'erreurs': stats_creation['erreurs'],
            'types_detectes': types_detectes,
            'ids_crees': stats_creation['ids_crees'],
            'periode_document': f"{doc_debut} → {doc_fin}" if doc_debut and doc_fin else "Indéterminée",
            'date_debut': str(doc_debut) if doc_debut else None,
            'date_fin': str(doc_fin) if doc_fin else None
        }

    def generer_propositions(self, evenement_ids: Optional[List[int]] = None) -> List[Dict]:
        """
        Génère les propositions d'écritures comptables pour des événements

        Args:
            evenement_ids: Liste d'IDs d'événements (None = tous les événements en attente)

        Returns:
            Liste de propositions
        """
        print()
        print("=" * 80)
        print("GÉNÉRATION DES PROPOSITIONS COMPTABLES")
        print("=" * 80)
        print()

        # Si aucun ID fourni, récupérer les événements en attente
        if evenement_ids is None:
            evenements = self.gestionnaire.obtenir_evenements_en_attente()
            evenement_ids = [evt['id'] for evt in evenements]

        if not evenement_ids:
            print("ℹ️  Aucun événement en attente")
            return []

        print(f"🔍 Analyse de {len(evenement_ids)} événements...")
        print()

        propositions = []
        for evt_id in evenement_ids:
            # Récupérer l'événement
            from sqlalchemy import text
            result = self.session.execute(
                text("""
                    SELECT id, date_operation, libelle, libelle_normalise,
                           montant, type_operation, type_evenement,
                           email_subject, email_body, email_date
                    FROM evenements_comptables
                    WHERE id = :id
                """),
                {'id': evt_id}
            )
            row = result.fetchone()
            if not row:
                continue

            evenement = {
                'id': row[0],
                'date_operation': row[1],
                'libelle': row[2],
                'libelle_normalise': row[3],
                'montant': float(row[4]) if row[4] else None,
                'type_operation': row[5],
                'type_evenement': row[6],
                'email_subject': row[7],
                'email_body': row[8],
                'email_date': row[9]
            }

            # EXCLURE les soldes d'ouverture (non comptabilisables)
            if evenement['type_evenement'] == 'SOLDE_OUVERTURE':
                print(f"⏭️  Événement #{evt_id} ignoré (SOLDE_OUVERTURE - non comptabilisable)")
                continue

            # Générer la proposition
            proposition = FactoryDetecteurs.detecter_et_proposer(
                self.session,
                evenement,
                phase=self.phase
            )

            if proposition:
                propositions.append({
                    'evenement_id': evt_id,
                    'proposition': proposition
                })

                print(f"✅ Événement #{evt_id}: {proposition['type_evenement']}")
                print(f"   Confiance: {proposition['confiance']}")
                print(f"   Écritures: {len(proposition['ecritures'])}")
                for ecriture in proposition['ecritures']:
                    print(f"     • {ecriture['compte_debit']} → {ecriture['compte_credit']}: "
                          f"{ecriture['montant']:.2f}€")
                print()

        print("=" * 80)
        print(f"✅ {len(propositions)} propositions générées")
        print("=" * 80)
        print()

        return propositions

    def afficher_stats(self):
        """Affiche les statistiques globales"""
        afficher_statistiques(self.gestionnaire)


# ═══════════════════════════════════════════════════════════════════════════════
# FONCTIONS UTILITAIRES
# ═══════════════════════════════════════════════════════════════════════════════

def traiter_pdf_complet(pdf_path: str, database_url: str, email_metadata: Optional[Dict] = None) -> Dict:
    """
    Fonction helper pour traiter un PDF en une seule commande

    Args:
        pdf_path: Chemin vers le PDF
        database_url: URL de la base de données
        email_metadata: Métadonnées de l'email (optionnel)

    Returns:
        Résultats du traitement
    """
    workflow = WorkflowEvenements(database_url, phase=1)
    resultats = workflow.traiter_pdf(pdf_path, email_metadata, auto_detect=True)
    return resultats


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN (CLI)
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import sys

    DATABASE_URL = os.getenv('DATABASE_URL')
    if DATABASE_URL and DATABASE_URL.startswith('postgres://'):
        DATABASE_URL = DATABASE_URL.replace('postgres://', 'postgresql://', 1)

    if not DATABASE_URL:
        print("❌ Variable DATABASE_URL non définie")
        sys.exit(1)

    print("=" * 80)
    print("WORKFLOW ÉVÉNEMENTS COMPTABLES")
    print("=" * 80)
    print()

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python workflow_evenements.py <pdf_path>           # Traiter un PDF")
        print("  python workflow_evenements.py --stats              # Afficher statistiques")
        print("  python workflow_evenements.py --propositions       # Générer propositions")
        print()
        print("Exemples:")
        print("  python workflow_evenements.py 'Elements Comptables des 1-2-3T2024.pdf'")
        print("  python workflow_evenements.py --stats")
        sys.exit(1)

    workflow = WorkflowEvenements(DATABASE_URL, phase=1)

    if sys.argv[1] == '--stats':
        # Afficher les statistiques
        workflow.afficher_stats()

    elif sys.argv[1] == '--propositions':
        # Générer les propositions pour les événements en attente
        propositions = workflow.generer_propositions()
        print(f"✅ {len(propositions)} propositions générées")

    else:
        # Traiter un PDF
        pdf_path = sys.argv[1]

        if not os.path.exists(pdf_path):
            print(f"❌ Fichier non trouvé: {pdf_path}")
            sys.exit(1)

        # Métadonnées fictives pour test
        email_metadata = {
            'email_id': f'email_{datetime.now().strftime("%Y%m%d_%H%M%S")}',
            'email_from': 'comptabilite@lcl.fr',
            'email_date': datetime.now(),
            'email_subject': 'Éléments comptables'
        }

        resultats = workflow.traiter_pdf(pdf_path, email_metadata, auto_detect=True)

        print()
        print("🎉 Traitement terminé!")
        print()
        print("Prochaines étapes:")
        print("  1. Vérifier les événements: python check_evenements.py")
        print("  2. Générer les propositions: python workflow_evenements.py --propositions")
        print("  3. Valider les propositions (manuel)")
        print("  4. Créer les écritures comptables")
